package com.cg.service;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.model.Response;

public interface OrderServices {

	public Product findByProductId(int pid);

	public Response updateInventory(int userId, String modeOfPurchase);

	public boolean updateProducts(int pid, int quantity);

	public String checkProducts(int userID);
	
	public Cart findByCartId(int cartID);
	

}

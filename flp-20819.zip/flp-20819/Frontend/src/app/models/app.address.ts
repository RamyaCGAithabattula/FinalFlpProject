export class Address{
    name:string;
    emailId:string;
    MobileNo:number;
    MobileNo2:number;
    address:string;
    address2:string;
    city:string;
    state:string;
    PinCode:number;
}
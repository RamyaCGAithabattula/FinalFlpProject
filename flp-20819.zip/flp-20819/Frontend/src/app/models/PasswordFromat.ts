export class PasswordFormat{

    email:string
    category:string
    answer1:string
    answer2:string
}
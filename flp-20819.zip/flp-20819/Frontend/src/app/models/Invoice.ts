export class Invoice {
    invoiceId: number
    userid: number
    firstname: string
    lastname: string
    mobileno: number
    emailid: string
    product: number[][]
    total: number
    dateofpurchase: Date
}
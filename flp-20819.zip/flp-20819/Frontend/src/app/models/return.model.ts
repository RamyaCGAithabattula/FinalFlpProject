import { Transaction } from "./Transaction.model";


export class productReturn {

    returnId: number;
    transaction: Transaction;
  //  product: Product;
    returnStatus: String;
    
    

  }
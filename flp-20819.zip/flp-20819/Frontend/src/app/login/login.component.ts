import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../Services/authentication.service';
import {Admin} from '../admin/admin.component'
import {Merchant} from '../merch/merch.component'
import { DataService } from '../Services/data.service';
import { User1 } from '../user1/user.component';
import { TouchSequence } from 'selenium-webdriver';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username=''
  password=''
  loginSess:number;
  errorMessage='Wrong input!!! Please check...'
  userType:string

  public ad:Admin
  public cu:User1
  public me:Merchant
  public str:string
  public str1:string = "productId here!"
  public str2:string
  public str3:string

  constructor(private router:Router,private auth:AuthenticationService,private service:DataService) {
    this.str2 = sessionStorage.getItem('admin')
    //alert(this.str2)
    if(this.str2 != null){
      this.router.navigate(['admin'])
    }

    this.str3 = sessionStorage.getItem('user')
    if(this.str3 != null){
      this.router.navigate(['home'])
    }
    // this.loginSess = sessionStorage.length;
    // if(this.loginSess!=0){
    //   alert("You are already logged in ");
    //   this.router.navigate(['home'])
    // }
  }
    
  ngOnInit() {
  }

  handelLogin(){
    
    this.service.retrieveAdmin(this.username,this.password).subscribe(
      data=>{
        this.ad = data
        //alert(this.ad.adminId)
        if(this.ad.emailid != ""){
        this.str = this.ad.adminId+""
        sessionStorage.setItem('admin', this.str)
        //alert("Hello1")
        this.router.navigate(['admin'])
        //alert(sessionStorage.length)
        }else{
          this.service.retrieveCustomer(this.username,this.password).subscribe(
            data=>{
              this.cu = data
              //alert(this.cu.userId)
              if(this.cu.emailid != ""){
              this.str = this.cu.userId+""
              sessionStorage.setItem('user', this.str)
              sessionStorage.setItem('productId',this.str1)
              this.router.navigate(['home'])
              //alert("Hello2")
              alert(sessionStorage.length)
              }else{
                this.service.retrieveMerchant(this.username,this.password).subscribe(
                  data=>{
                    this.me = data
                    //alert(this.me.merchantId)
                    if(this.me.emailid != ""){
                    this.str = this.me.merchantId+""
                    sessionStorage.setItem('merchant', this.str)
                    this.router.navigate(['merch'])
                    //alert("Hello3")
                    alert(sessionStorage.length)
                    }else{
                      alert(" Invalid log-on. Please try with valid details...")
                    }
                  }
                )
              }
              
            }
          )
        }
      }
    )
    
  }


}

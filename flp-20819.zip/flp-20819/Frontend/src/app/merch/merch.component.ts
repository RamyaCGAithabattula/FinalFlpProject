import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

export class Merchant{
  constructor(
    public merchantId:number=0,
    public firstName:string="",
    public lastName:string="",
    public company:string="",
    public emailid:string="",
    public mobileno:number=0,
    public password:string="",
    public photo:string="",
    public rating:number=0,
    public status:string=""
  ){}
}
@Component({
  selector: 'app-merch',
  templateUrl: './merch.component.html',
  styleUrls: ['./merch.component.css']
})
export class MerchComponent implements OnInit {

  str:string
  constructor(private router:Router) { }

  ngOnInit() {
    this.str = sessionStorage.getItem('merchant')
    //alert(this.str2)
    if(this.str == null){
      this.router.navigate(['login'])
    }
  }

}

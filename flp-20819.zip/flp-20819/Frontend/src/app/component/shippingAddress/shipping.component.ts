import { Component} from '@angular/core';
import { AddressService } from 'src/app/Services/addressService';
import { Address } from 'src/app/models/app.address';
import {Response} from "../../models/response"
import { Router } from '@angular/router';

@Component({
    selector: 'shipping',
    templateUrl: 'shipping.component.html'
})
export class ShippingComponent { 
    Address:Address={
        name:'',
        emailId:'',
        MobileNo:null,
        MobileNo2:null,
        address:'',
        address2:'',
        city:'',
        state:'',
        PinCode:null
    }
    all:string;
    constructor( private addressService: AddressService, private router: Router){
    }

response: Response;

   addData():void{

       if(this.Address.MobileNo < 1000000000 || this.Address.MobileNo > 9999999999){
           alert("Mobile number should be of 10 digits only")
       }

       if(this.Address.PinCode < 100000 || this.Address.PinCode > 999999){
           alert("PinCode should be of 6 digits only")
       }
       
       this.all=this.Address.address+" "+this.Address.address2+" "+this.Address.city+" "+this.Address.state+" "+this.Address.PinCode;
       this.addressService.addData(this.Address).subscribe(
           res=>{
                this.response = res;
                if(this.response.status === 200){
                    alert(this.response.message)
                    this.router.navigate(['payment']);
                }
           }
       );
   };
}